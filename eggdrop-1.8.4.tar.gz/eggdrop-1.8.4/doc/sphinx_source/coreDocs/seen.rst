Last revised: January 1, 2002

.. _seen:

===========
Seen Module
===========

This module provides very basic seen commands via msg, on channel or via dcc.
This module works only for users in the bot's userlist. If you are looking
for a better and more advanced seen module, try the gseen module by G'Quann.
You can find it at http://www.kreativrauschen.com/gseen.mod/.

This module requires: none

Put this line into your Eggdrop configuration file to load the seen module::

  loadmodule seen


Copyright (C) 2000 - 2018 Eggheads Development Team
